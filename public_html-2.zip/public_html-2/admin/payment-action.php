<?php
require_once __DIR__ . '/_layout.php';
require_admin();
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_check($_POST['csrf'] ?? '')) {
    flash_set('err', 'Ошибка запроса.'); header('Location: /admin/dashboard.php'); exit;
}
$id = (int)($_POST['id'] ?? 0);
$act = $_POST['act'] ?? '';
$back = $_POST['back'] ?? '/admin/dashboard.php';

$st = db()->prepare("SELECT * FROM payments WHERE id=?");
$st->execute([$id]);
$pay = $st->fetch();
if (!$pay) { flash_set('err', 'Оплата не найдена.'); header("Location: $back"); exit; }

if ($act === 'ok') {
    db()->prepare("UPDATE payments SET status='approved', reviewed_at=datetime('now') WHERE id=?")->execute([$id]);
    if ((int)$pay['stage'] === 1) schedule_stage2($pay['user_id']);
    flash_set('ok', "Оплата #$id подтверждена.");
} elseif ($act === 'no') {
    db()->prepare("UPDATE payments SET status='rejected', reviewed_at=datetime('now') WHERE id=?")->execute([$id]);
    flash_set('ok', "Оплата #$id отклонена.");
}
header("Location: $back");
exit;
