<?php
require_once __DIR__ . '/_layout.php';

if (admin_logged_in()) { header('Location: /admin/dashboard.php'); exit; }

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) {
        $err = 'Сессия истекла, попробуйте снова.';
    } else {
        $user = trim($_POST['user'] ?? '');
        $pass = (string)($_POST['pass'] ?? '');
        if ($user === setting('admin_user') && password_verify($pass, (string)setting('admin_pass_hash'))) {
            session_regenerate_id(true);
            $_SESSION['admin'] = true;
            header('Location: /admin/dashboard.php'); exit;
        }
        $err = 'Неверный логин или пароль.';
    }
}
?><!DOCTYPE html><html lang="ru"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Вход — Админка</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/style.css?v=<?= APP_VER ?>">
</head><body class="adm-body">
<form class="adm-login" method="post">
  <h1 style="font-size:1.4rem;margin-bottom:6px">GTD Админка</h1>
  <p class="muted" style="margin-bottom:22px">Вход в панель управления</p>
  <?php if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
  <div class="adm-field"><label>Логин</label><input type="text" name="user" autofocus autocomplete="username"></div>
  <div class="adm-field"><label>Пароль</label><input type="password" name="pass" autocomplete="current-password"></div>
  <button class="adm-btn" style="width:100%" type="submit">Войти</button>
</form>
</body></html>
