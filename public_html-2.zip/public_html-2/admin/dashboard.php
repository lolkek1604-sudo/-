<?php
require_once __DIR__ . '/_layout.php';
require_admin();
$pdo = db();

$users   = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$apps    = (int)$pdo->query("SELECT COUNT(*) FROM applications")->fetchColumn();
$pending = (int)$pdo->query("SELECT COUNT(*) FROM payments WHERE status='awaiting_review'")->fetchColumn();
$paidCnt = (int)$pdo->query("SELECT COUNT(*) FROM payments WHERE status='approved'")->fetchColumn();
$revenue = (int)$pdo->query("SELECT COALESCE(SUM(amount_uzs),0) FROM payments WHERE status='approved'")->fetchColumn();

$byStatus = [
    'awaiting_payment' => 0, 'awaiting_review' => 0, 'approved' => 0, 'rejected' => 0, 'locked' => 0,
];
foreach ($pdo->query("SELECT status, COUNT(*) c FROM payments GROUP BY status") as $r) {
    if (isset($byStatus[$r['status']])) $byStatus[$r['status']] = (int)$r['c'];
}

$recent = $pdo->query("
    SELECT a.id, a.created_at, a.status, u.name
    FROM applications a JOIN users u ON u.id=a.user_id
    ORDER BY a.id DESC LIMIT 6")->fetchAll();

admin_head('dashboard', 'Обзор');
?>
<h1 class="page-h1">Обзор</h1>
<p class="page-sub">Сводка по заявкам, клиентам и оплатам</p>

<div class="kpi-grid">
  <div class="kpi">
    <div class="kh">Клиентов <span class="kic"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><circle cx="9" cy="8" r="3"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/></svg></span></div>
    <div class="kn"><?= $users ?></div>
  </div>
  <div class="kpi">
    <div class="kh">Анкет <span class="kic"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5"/></svg></span></div>
    <div class="kn"><?= $apps ?></div>
    <div class="kx"><?= $pending ?> на проверке оплат</div>
  </div>
  <div class="kpi green">
    <div class="kh">Выручка <span class="kic"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M12 3v18M7 7h7a3 3 0 0 1 0 6H8m9 4H9"/></svg></span></div>
    <div class="kn"><?= number_format($revenue, 0, '.', ' ') ?></div>
    <div class="kx">сум · подтверждённые</div>
  </div>
  <div class="kpi amber">
    <div class="kh">Оплат на проверке <span class="kic"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><circle cx="12" cy="12" r="9"/><path d="M12 8v4l3 2"/></svg></span></div>
    <div class="kn"><?= $pending ?></div>
    <div class="kx">ждут вашего решения</div>
  </div>
</div>

<div class="two-col">
  <div class="adm-card">
    <h2>Статусы оплат</h2>
    <div class="slist">
      <div class="srow b-amber"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#b7791f" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 8v4"/></svg> Ожидают оплаты <span class="sc"><?= $byStatus['awaiting_payment'] ?></span></div>
      <div class="srow b-blue"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1d4fa2" stroke-width="1.8"><path d="M4 16l4-4 4 4 4-5 4 5"/></svg> На проверке <span class="sc"><?= $byStatus['awaiting_review'] ?></span></div>
      <div class="srow b-green"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#137a45" stroke-width="1.8"><path d="m5 12 5 5L19 7"/></svg> Подтверждены <span class="sc"><?= $byStatus['approved'] ?></span></div>
      <div class="srow b-red"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#c02626" stroke-width="1.8"><path d="m8 8 8 8M16 8l-8 8"/></svg> Отклонены <span class="sc"><?= $byStatus['rejected'] ?></span></div>
      <div class="srow b-violet"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6c2bd9" stroke-width="1.8"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg> Заблокированы (2-й этап) <span class="sc"><?= $byStatus['locked'] ?></span></div>
    </div>
  </div>

  <div class="adm-card">
    <h2>Быстрые действия</h2>
    <div class="slist">
      <a class="srow" href="/admin/payments.php?status=awaiting_review"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#5b6b7d" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18"/></svg> Проверить оплаты <span class="sc"><?= $pending ?></span></a>
      <a class="srow" href="/admin/applications.php"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#5b6b7d" stroke-width="1.8"><path d="M7 3h7l5 5v13H7z"/></svg> Анкеты клиентов</a>
      <a class="srow" href="/admin/banks.php"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#5b6b7d" stroke-width="1.8"><path d="M4 10h16L12 4z"/><path d="M6 10v8m12-8v8M4 20h16"/></svg> Настроить банки и реквизиты</a>
      <a class="srow" href="/admin/settings.php"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#5b6b7d" stroke-width="1.8"><circle cx="12" cy="12" r="3"/><path d="M4 12h2m12 0h2M12 4v2m0 12v2"/></svg> Настройки, бот, курс</a>
    </div>
  </div>
</div>

<div class="adm-card" style="margin-top:20px">
  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
    <h2 style="margin:0">Последние анкеты</h2>
    <a class="adm-btn sm" href="/admin/applications.php" style="background:#eef2f7;color:#16324f">Все анкеты</a>
  </div>
  <?php if (!$recent): ?>
    <p class="muted">Пока нет анкет.</p>
  <?php else: ?>
  <div style="overflow-x:auto"><table class="adm-table">
    <tr><th>#</th><th>Клиент</th><th>Дата</th><th></th></tr>
    <?php foreach ($recent as $r): ?>
      <tr>
        <td>APP-<?= str_pad($r['id'], 3, '0', STR_PAD_LEFT) ?></td>
        <td><?= e($r['name']) ?></td>
        <td><?= e($r['created_at']) ?></td>
        <td><a class="adm-btn sm" href="/admin/applications.php?id=<?= (int)$r['id'] ?>">Открыть</a></td>
      </tr>
    <?php endforeach; ?>
  </table></div>
  <?php endif; ?>
</div>
<?php admin_foot();
