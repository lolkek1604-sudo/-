<?php
require_once __DIR__ . '/_layout.php';
require_admin();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_check($_POST['csrf'] ?? '')) {
    $uid = (int)($_POST['id'] ?? 0);
    $act = $_POST['act'] ?? '';
    if ($act === 'delete') {
        $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$uid]);
        $pdo->prepare("DELETE FROM applications WHERE user_id=?")->execute([$uid]);
        $pdo->prepare("DELETE FROM documents WHERE user_id=?")->execute([$uid]);
        $pdo->prepare("DELETE FROM payments WHERE user_id=?")->execute([$uid]);
        flash_set('ok', 'Клиент удалён.');
    } elseif ($act === 'verify') {
        $pdo->prepare("UPDATE users SET verified=1, verify_token='' WHERE id=?")->execute([$uid]);
        flash_set('ok', 'Email клиента подтверждён вручную.');
    }
    header('Location: /admin/users.php'); exit;
}

$rows = $pdo->query("SELECT * FROM users ORDER BY id DESC")->fetchAll();
$total = count($rows);
admin_head('users', 'Клиенты');
?>
<h1 class="page-h1">Клиенты</h1>
<p class="page-sub">Все зарегистрированные пользователи</p>

<div class="kpi-grid">
  <div class="kpi"><div class="kh">Всего клиентов</div><div class="kn"><?= $total ?></div></div>
  <div class="kpi"><div class="kh">С анкетой</div><div class="kn"><?= (int)$pdo->query("SELECT COUNT(DISTINCT user_id) FROM applications")->fetchColumn() ?></div></div>
</div>

<div class="adm-card">
  <input type="text" id="uSearch" placeholder="Поиск по имени, email или телефону…"
    style="width:100%;padding:.75rem 1rem;border:1px solid var(--border);border-radius:10px;font-family:inherit;font-size:.95rem;background:var(--soft);margin-bottom:16px">
  <div style="overflow-x:auto"><table class="adm-table" id="uTable">
    <tr><th>Клиент</th><th>Телефон</th><th>Роль</th><th>Регистрация</th><th></th></tr>
    <?php foreach ($rows as $u): ?>
      <tr>
        <td>
          <div style="display:flex;align-items:center;gap:10px">
            <span style="width:34px;height:34px;border-radius:50%;background:#16324f;color:#fff;display:grid;place-items:center;font-weight:700;flex:none"><?= e(mb_strtoupper(mb_substr($u['name'],0,1))) ?></span>
            <span><b><?= e($u['name']) ?></b><br><small class="muted"><?= e($u['email']) ?></small></span>
          </div>
        </td>
        <td><?= e($u['phone']) ?></td>
        <td>
          <?php if ((int)($u['verified'] ?? 1) === 1): ?><span class="tag ok">email ✓</span>
          <?php else: ?><span class="tag amber">не подтверждён</span><?php endif; ?>
        </td>
        <td><?= e(date('d.m.Y', strtotime($u['created_at']))) ?></td>
        <td style="white-space:nowrap">
          <?php if ((int)($u['verified'] ?? 1) === 0): ?>
          <form method="post" style="display:inline">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="act" value="verify"><input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
            <button class="adm-btn green sm" type="submit">Подтвердить</button>
          </form>
          <?php endif; ?>
          <form method="post" onsubmit="return confirm('Удалить этого клиента и все его данные?')" style="display:inline">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="act" value="delete">
            <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
            <button class="adm-btn red sm" type="submit">Удалить</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
  <?php if (!$rows): ?><p class="muted">Пока нет клиентов.</p><?php endif; ?>
</div>
<script>
document.getElementById('uSearch').addEventListener('input', function(){
  const q = this.value.toLowerCase();
  document.querySelectorAll('#uTable tr').forEach((tr,i)=>{ if(i===0) return;
    tr.style.display = tr.textContent.toLowerCase().includes(q) ? '' : 'none'; });
});
</script>
<?php admin_foot();
