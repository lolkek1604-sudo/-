<?php
require_once __DIR__ . '/_layout.php';
require_admin();
$pdo = db();
$filter = $_GET['status'] ?? 'all';
$statusTag = ['awaiting_review'=>['await','На проверке'],'approved'=>['ok','Подтверждено'],'rejected'=>['no','Отклонено'],'awaiting_payment'=>['none','Ожидает оплаты'],'locked'=>['locked','Заблокировано'],'none'=>['none','—']];

$where = '';
$params = [];
if (in_array($filter, array_keys($statusTag), true)) { $where = "WHERE p.status=?"; $params[] = $filter; }
$rows = $pdo->prepare("SELECT p.*, u.name, u.phone FROM payments p JOIN users u ON u.id=p.user_id $where ORDER BY p.id DESC");
$rows->execute($params);
$rows = $rows->fetchAll();

admin_head('payments', 'Оплаты');
?>
<h1>Оплаты</h1>
<div class="adm-card">
  <div style="margin-bottom:16px;display:flex;gap:8px;flex-wrap:wrap">
    <?php foreach (['all'=>'Все','awaiting_review'=>'На проверке','approved'=>'Подтверждённые','rejected'=>'Отклонённые','awaiting_payment'=>'Ожидают'] as $k=>$l): ?>
      <a class="adm-btn sm <?= $filter===$k?'':'' ?>" style="<?= $filter===$k?'':'background:#eef2f7;color:#5b6b7d' ?>" href="?status=<?= $k ?>"><?= e($l) ?></a>
    <?php endforeach; ?>
  </div>
  <?php if (!$rows): ?><p class="muted">Нет записей.</p><?php else: ?>
  <div style="overflow-x:auto"><table class="adm-table">
    <tr><th>#</th><th>Клиент</th><th>Этап</th><th>Сумма</th><th>Банк</th><th>Статус</th><th>Скрин</th><th>Дата</th><th>Действие</th></tr>
    <?php foreach ($rows as $p): $t=$statusTag[$p['status']]??['none',$p['status']]; ?>
      <tr>
        <td>#<?= (int)$p['id'] ?></td>
        <td><?= e($p['name']) ?><br><small class="muted"><?= e($p['phone']) ?></small></td>
        <td><?= (int)$p['stage'] ?></td>
        <td><?= number_format((int)$p['amount_uzs'],0,'.',' ') ?> сум</td>
        <td><?= e($p['bank_name'] ?: '—') ?></td>
        <td><span class="tag <?= $t[0] ?>"><?= e($t[1]) ?></span></td>
        <td><?php if ($p['screenshot']): ?><a href="/data/uploads/<?= e($p['screenshot']) ?>" target="_blank">открыть</a><?php else: ?>—<?php endif; ?></td>
        <td><small><?= e($p['created_at']) ?></small></td>
        <td>
          <?php if ($p['status']==='awaiting_review'): ?>
          <form method="post" action="/admin/payment-action.php" style="display:inline">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
            <input type="hidden" name="back" value="/admin/payments.php?status=<?= e($filter) ?>">
            <button class="adm-btn green sm" name="act" value="ok">✅</button>
            <button class="adm-btn red sm" name="act" value="no">❌</button>
          </form>
          <?php else: ?>—<?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
  </table></div>
  <?php endif; ?>
</div>
<?php admin_foot();
