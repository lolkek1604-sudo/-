<?php
require_once __DIR__ . '/_layout.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) { flash_set('err','Сессия истекла.'); header('Location: /admin/settings.php'); exit; }
    $action = $_POST['action'] ?? 'save';

    if ($action === 'payram_save') {
        setting_set('payram_enabled', isset($_POST['payram_enabled']) ? '1' : '0');
        setting_set('payram_base_url', rtrim(trim($_POST['payram_base_url'] ?? ''), '/'));
        if (trim($_POST['payram_api_key'] ?? '') !== '') setting_set('payram_api_key', trim($_POST['payram_api_key']));
        if (trim($_POST['payram_webhook_secret'] ?? '') !== '') setting_set('payram_webhook_secret', trim($_POST['payram_webhook_secret']));
        setting_set('payram_checkout_mode', (($_POST['payram_checkout_mode'] ?? 'iframe') === 'redirect') ? 'redirect' : 'iframe');
        setting_set('payram_eur_usd_rate', max(0, (float)($_POST['payram_eur_usd_rate'] ?? 1.08)));
        flash_set('ok', 'Настройки PayRam сохранены.');

    } elseif ($action === 'save') {
        setting_set('bot_token', trim($_POST['bot_token'] ?? ''));
        setting_set('admin_chat_id', trim($_POST['admin_chat_id'] ?? ''));
        setting_set('usd_uzs_rate', max(0, (float)($_POST['usd_uzs_rate'] ?? 0)));
        setting_set('price1_usd', max(0, (float)($_POST['price1_usd'] ?? 0)));
        setting_set('price2_usd', max(0, (float)($_POST['price2_usd'] ?? 0)));
        setting_set('stage2_delay_days', max(0, (int)($_POST['stage2_delay_days'] ?? 5)));
        setting_set('manager_contact', trim($_POST['manager_contact'] ?? ''));
        flash_set('ok', 'Настройки сохранены.');

    } elseif ($action === 'email') {
        setting_set('require_email_verify', isset($_POST['require_email_verify']) ? '1' : '0');
        setting_set('support_email', trim($_POST['support_email'] ?? ''));
        setting_set('smtp_host', trim($_POST['smtp_host'] ?? ''));
        setting_set('smtp_port', (int)($_POST['smtp_port'] ?? 587));
        setting_set('smtp_secure', in_array($_POST['smtp_secure'] ?? 'tls', ['tls','ssl','none'], true) ? $_POST['smtp_secure'] : 'tls');
        setting_set('smtp_user', trim($_POST['smtp_user'] ?? ''));
        if (($_POST['smtp_pass'] ?? '') !== '') setting_set('smtp_pass', $_POST['smtp_pass']);
        setting_set('smtp_from', trim($_POST['smtp_from'] ?? ''));
        setting_set('smtp_from_name', trim($_POST['smtp_from_name'] ?? ''));
        flash_set('ok', 'Настройки email сохранены.');

    } elseif ($action === 'contract') {
        setting_set('co_name', trim($_POST['co_name'] ?? ''));
        setting_set('co_director', trim($_POST['co_director'] ?? ''));
        setting_set('co_basis', trim($_POST['co_basis'] ?? ''));
        setting_set('co_requisites', trim($_POST['co_requisites'] ?? ''));
        setting_set('contract_city', trim($_POST['contract_city'] ?? ''));
        // seal + signature (PNG) upload / remove
        if (!empty($_POST['remove_seal'])) setting_set('co_seal_file', '');
        if (!empty($_POST['remove_signature'])) setting_set('co_signature_file', '');
        if (!empty($_FILES['co_seal']['name'])) { $s = save_upload('co_seal', 'seal'); if ($s) setting_set('co_seal_file', $s['filename']); }
        if (!empty($_FILES['co_signature']['name'])) { $s = save_upload('co_signature', 'sign'); if ($s) setting_set('co_signature_file', $s['filename']); }
        flash_set('ok', 'Реквизиты договора сохранены.');

    } elseif ($action === 'test_mail') {
        require_once __DIR__ . '/../includes/mailer.php';
        $err = null;
        $to = trim($_POST['test_to'] ?? '') ?: setting('support_email');
        $ok = send_mail($to, 'Тест — Gateway to Dreams', '<p>Проверка отправки почты прошла успешно ✅</p>', $err);
        if ($ok) flash_set('ok', 'Тестовое письмо отправлено на ' . $to);
        else flash_set('err', 'Не удалось отправить: ' . ($err ?: 'проверьте настройки SMTP'));

    } elseif ($action === 'admin_creds') {
        $u = trim($_POST['admin_user'] ?? '');
        $p = (string)($_POST['admin_pass'] ?? '');
        if ($u !== '') setting_set('admin_user', $u);
        if (strlen($p) >= 6) setting_set('admin_pass_hash', password_hash($p, PASSWORD_DEFAULT));
        flash_set('ok', 'Доступ администратора обновлён.');

    } elseif ($action === 'set_webhook') {
        $secret = bin2hex(random_bytes(16));
        setting_set('webhook_secret', $secret);
        $host = $_SERVER['HTTP_HOST'] ?? '';
        $url = 'https://' . $host . '/api/telegram-webhook.php';
        $res = tg_api('setWebhook', ['url' => $url, 'secret_token' => $secret, 'allowed_updates' => ['message','callback_query']]);
        if (!empty($res['ok'])) flash_set('ok', 'Webhook установлен: ' . $url);
        else flash_set('err', 'Не удалось установить webhook: ' . ($res['description'] ?? $res['error'] ?? 'ошибка. Проверьте токен.'));
    } elseif ($action === 'test_tg') {
        $res = tg_send_message('✅ Проверка связи. Бот подключён к Gateway to Dreams.');
        if (!empty($res['ok'])) flash_set('ok', 'Сообщение отправлено в Telegram.');
        else flash_set('err', 'Ошибка отправки: ' . ($res['description'] ?? $res['error'] ?? 'проверьте токен и chat_id.'));

    } elseif ($action === 'bot2_save') {
        setting_set('bot2_token', trim($_POST['bot2_token'] ?? ''));
        setting_set('bot2_chat_id', trim($_POST['bot2_chat_id'] ?? ''));
        setting_set('tg_admin_ids', trim($_POST['tg_admin_ids'] ?? ''));
        flash_set('ok', 'Второй бот сохранён.');

    } elseif ($action === 'webhook_info') {
        $out = [];
        foreach ([['Бот 1', trim((string)setting('bot_token'))], ['Бот 2', trim((string)setting('bot2_token'))]] as $b) {
            if ($b[1] === '') { $out[] = "{$b[0]}: токен не задан"; continue; }
            $r = tg_api('getWebhookInfo', [], false, $b[1]);
            if (empty($r['ok'])) { $out[] = "{$b[0]}: ошибка запроса"; continue; }
            $i = $r['result'];
            $out[] = "{$b[0]}: url=" . ($i['url'] ?: 'НЕ УСТАНОВЛЕН')
                . '; в очереди=' . (int)($i['pending_update_count'] ?? 0)
                . (!empty($i['last_error_message']) ? '; последняя ошибка: ' . $i['last_error_message'] : '; ошибок нет');
        }
        flash_set(strpos(implode(' ', $out), 'НЕ УСТАНОВЛЕН') !== false ? 'err' : 'ok', implode(' | ', $out));

    } elseif ($action === 'test_tg2') {
        $t = trim((string)setting('bot2_token'));
        $c = trim((string)setting('bot2_chat_id'));
        $res = tg_send_message('✅ Проверка связи. Бот платежей подключён к группе.', $c ?: null, null, $t ?: null);
        if (!empty($res['ok'])) flash_set('ok', 'Сообщение отправлено во второй бот.');
        else flash_set('err', 'Ошибка отправки: ' . ($res['description'] ?? $res['error'] ?? 'проверьте токен и ID группы.'));

    } elseif ($action === 'set_webhook2') {
        $t = trim((string)setting('bot2_token'));
        if ($t === '') { flash_set('err', 'Сначала сохраните токен второго бота.'); header('Location: /admin/settings.php'); exit; }
        $secret = bin2hex(random_bytes(16));
        setting_set('webhook2_secret', $secret);
        $host = $_SERVER['HTTP_HOST'] ?? '';
        $url = 'https://' . $host . '/api/telegram-webhook2.php';
        $res = tg_api('setWebhook', ['url' => $url, 'secret_token' => $secret, 'allowed_updates' => ['message','callback_query']], false, $t);
        // register the command menu so the bot shows a visible "Меню" button
        tg_api('setMyCommands', ['commands' => [
            ['command' => 'admin', 'description' => 'Реквизиты банков (для админов)'],
            ['command' => 'id',    'description' => 'Показать мой Telegram ID и ID чата'],
        ]], false, $t);
        if (!empty($res['ok'])) flash_set('ok', 'Webhook второго бота установлен: ' . $url . ' — меню команд добавлено.');
        else flash_set('err', 'Не удалось установить webhook: ' . ($res['description'] ?? $res['error'] ?? 'проверьте токен.'));
    }
    header('Location: /admin/settings.php'); exit;
}

$rate = (float)setting('usd_uzs_rate');
$p1 = (float)setting('price1_usd'); $p2 = (float)setting('price2_usd');
admin_head('settings', 'Настройки');
?>
<h1>Настройки</h1>

<form method="post" class="adm-card">
  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
  <input type="hidden" name="action" value="payram_save">
  <h2>PayRam — Card → Crypto</h2>
  <p class="muted" style="margin:-6px 0 14px">
  PayRam используется для создания и обработки платежей.
  Платёж создаётся сервером GatewayToDreams, после чего клиент
  перенаправляется на страницу оплаты. API key в браузер не передаётся.
</p>
<label class="switch" style="margin-bottom:14px">
    <input type="checkbox" name="payram_enabled" <?= setting('payram_enabled','0')==='1'?'checked':'' ?>>
    Включить PayRam для клиентов
  </label>
  <div class="adm-field"><label>PayRam URL</label><input type="url" name="payram_base_url" value="<?= e(setting('payram_base_url','')) ?>" placeholder="https://payram.example.com"><small>URL вашего self-hosted PayRam без завершающего /.</small></div>
  <div class="adm-field"><label>Merchant API key</label><input type="password" name="payram_api_key" placeholder="<?= setting('payram_api_key')?'•••••••••••••• (не менять — оставьте пустым)':'pr_live_...' ?>"><small>Используется backend-ом в заголовке <code>API-Key</code>. В браузер не отправляется.</small></div>
  <div class="adm-field"><label>Webhook shared secret</label><input type="password" name="payram_webhook_secret" placeholder="<?= setting('payram_webhook_secret')?'•••••••••••••• (не менять — оставьте пустым)':'секрет из PayRam' ?>"><small>PayRam Core 3.8.x отправляет его в заголовке <code>API-Key</code> на <code>/api/payram-webhook.php</code>. Проверка выполняется constant-time. <code>X-PayRam-Signature</code> не требуется текущим Core.</small></div>
  <div class="adm-field"><label>Режим оплаты</label><select name="payram_checkout_mode"><option value="iframe" <?= setting('payram_checkout_mode','iframe')!=='redirect'?'selected':'' ?>>Внутри моего сайта (iframe)</option><option value="redirect" <?= setting('payram_checkout_mode','iframe')==='redirect'?'selected':'' ?>>Переход на страницу PayRam</option></select><small>Iframe работает, только если PayRam-нода разрешает встраивание (frame-ancestors) для вашего домена.</small></div>
  <div class="adm-field"><label>Курс EUR → USD</label><input type="number" step="0.0001" name="payram_eur_usd_rate" value="<?= e(setting('payram_eur_usd_rate','1.08')) ?>"><small>PayRam merchant API принимает сумму в USD; этот курс можно использовать для отображения EUR-эквивалента.</small></div>
  <div class="result-box ok" style="margin-top:12px"><div><b>Webhook URL:</b> https://<?= e($_SERVER['HTTP_HOST'] ?? 'YOUR-DOMAIN') ?>/api/payram-webhook.php</div></div>
  <button class="adm-btn green" type="submit">Сохранить PayRam</button>
</form>

<form method="post">
  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
  <input type="hidden" name="action" value="save">

  <div class="adm-card">
    <h2>Платежи и курс</h2>
    <div class="adm-field">
      <label>Курс USD → UZS (курс Рапира)</label>
      <input type="number" step="0.01" name="usd_uzs_rate" value="<?= e($rate) ?>">
      <small>Сумма в сумах пересчитывается автоматически по этому курсу.</small>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
      <div class="adm-field"><label>Первый платёж, $</label><input type="number" step="0.01" name="price1_usd" value="<?= e($p1) ?>">
        <small>≈ <?= number_format(usd_to_uzs($p1,$rate),0,'.',' ') ?> сум</small></div>
      <div class="adm-field"><label>Второй платёж, $</label><input type="number" step="0.01" name="price2_usd" value="<?= e($p2) ?>">
        <small>≈ <?= number_format(usd_to_uzs($p2,$rate),0,'.',' ') ?> сум</small></div>
    </div>
    <div class="adm-field"><label>Задержка появления 2-го платежа (дней)</label>
      <input type="number" name="stage2_delay_days" value="<?= e(setting('stage2_delay_days')) ?>">
      <small>Второй платёж появляется у клиента ровно через это число дней после подтверждения первого.</small></div>
    <div class="adm-field"><label>Контакт менеджера (показывается при отказе оплаты)</label>
      <input type="text" name="manager_contact" value="<?= e(setting('manager_contact')) ?>" placeholder="@username или телефон"></div>
    <button class="adm-btn" type="submit">Сохранить</button>
  </div>

  <div class="adm-card">
    <h2>Telegram-бот</h2>
    <div class="adm-field"><label>Токен бота (@BotFather)</label>
      <input type="text" name="bot_token" value="<?= e(setting('bot_token')) ?>" placeholder="123456:ABC-DEF..."></div>
    <div class="adm-field"><label>Chat ID администратора</label>
      <input type="text" name="admin_chat_id" value="<?= e(setting('admin_chat_id')) ?>" placeholder="напр. 123456789">
      <small>Напишите боту команду <b>/id</b> — он пришлёт ваш chat_id. Скрины оплат приходят сюда.</small></div>
    <button class="adm-btn" type="submit">Сохранить токен</button>
  </div>
</form>

<div class="adm-card">
  <h2>Подключение бота</h2>
  <p class="muted" style="margin-bottom:14px">После сохранения токена и chat_id: нажмите «Проверить связь», затем «Установить webhook», чтобы кнопки ✅/❌ в чате работали.</p>
  <div style="display:flex;gap:10px;flex-wrap:wrap">
    <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="test_tg"><button class="adm-btn" type="submit">Проверить связь</button></form>
    <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="set_webhook"><button class="adm-btn green" type="submit">Установить webhook</button></form>
  </div>
</div>

<form method="post" class="adm-card">
  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
  <input type="hidden" name="action" value="bot2_save">
  <h2>Второй бот — платежи (группа)</h2>
  <p class="muted" style="margin:-6px 0 14px;font-size:.85rem">Отдельный бот только для оплат. Добавьте его в группу, где команда подтверждает платежи. Скрины оплат приходят сюда с кнопками ✅/❌.</p>
  <div class="adm-field"><label>Токен второго бота (@BotFather)</label><input type="text" name="bot2_token" value="<?= e(setting('bot2_token')) ?>" placeholder="123456:ABC-DEF..."></div>
  <div class="adm-field"><label>ID группы</label><input type="text" name="bot2_chat_id" value="<?= e(setting('bot2_chat_id')) ?>" placeholder="напр. -1001234567890">
    <small>Добавьте бота в группу и напишите там <b>/id</b> — он пришлёт ID группы. Обычно начинается с «-100…».</small></div>
  <div class="adm-field"><label>Telegram ID администраторов (админка в боте)</label>
    <textarea name="tg_admin_ids" rows="2" placeholder="123456789, 987654321"><?= e(setting('tg_admin_ids')) ?></textarea>
    <small>Кому доступна команда <b>/admin</b> в боте (смена реквизитов). Свой ID можно узнать, написав боту <b>/id</b>. Несколько — через запятую.</small></div>
  <button class="adm-btn" type="submit">Сохранить второй бот</button>
</form>

<div class="adm-card">
  <h2>Подключение второго бота</h2>
  <p class="muted" style="margin-bottom:14px">После сохранения токена и ID группы: «Проверить связь», затем «Установить webhook», чтобы кнопки ✅/❌ в группе работали.</p>
  <div style="display:flex;gap:10px;flex-wrap:wrap">
    <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="test_tg2"><button class="adm-btn" type="submit">Проверить связь</button></form>
    <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="set_webhook2"><button class="adm-btn green" type="submit">Установить webhook</button></form>
    <form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="action" value="webhook_info"><button class="adm-btn" type="submit" style="background:#eef2f7;color:#16324f">🔍 Диагностика ботов</button></form>
  </div>
  <p class="muted" style="margin-top:12px;font-size:.85rem">«Диагностика» покажет, установлены ли webhook у обоих ботов и есть ли ошибки. Если кнопки ✅/❌ в группе не срабатывают — почти всегда webhook второго бота не установлен.</p>
</div>

<form method="post" class="adm-card">
  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
  <input type="hidden" name="action" value="email">
  <h2>Email и подтверждение</h2>
  <label class="switch" style="margin-bottom:14px">
    <input type="checkbox" name="require_email_verify" <?= setting('require_email_verify')==='1'?'checked':'' ?>>
    Требовать подтверждение email при регистрации
  </label>
  <p class="muted" style="margin:-6px 0 16px;font-size:.85rem">Включайте только после настройки SMTP ниже, иначе клиенты не смогут подтвердить почту.</p>
  <div class="adm-field"><label>Email поддержки (виден клиентам)</label><input type="text" name="support_email" value="<?= e(setting('support_email')) ?>"></div>
  <div style="display:grid;grid-template-columns:2fr 1fr 1fr;gap:14px">
    <div class="adm-field"><label>SMTP хост</label><input type="text" name="smtp_host" value="<?= e(setting('smtp_host')) ?>" placeholder="smtp.gmail.com"></div>
    <div class="adm-field"><label>Порт</label><input type="number" name="smtp_port" value="<?= e(setting('smtp_port')) ?>"></div>
    <div class="adm-field"><label>Шифрование</label>
      <select name="smtp_secure">
        <?php foreach (['tls'=>'TLS (587)','ssl'=>'SSL (465)','none'=>'без шифрования'] as $v=>$l): ?>
          <option value="<?= $v ?>" <?= setting('smtp_secure')===$v?'selected':'' ?>><?= $l ?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
    <div class="adm-field"><label>SMTP логин</label><input type="text" name="smtp_user" value="<?= e(setting('smtp_user')) ?>" placeholder="you@gmail.com"></div>
    <div class="adm-field"><label>SMTP пароль</label><input type="password" name="smtp_pass" placeholder="<?= setting('smtp_pass')?'•••••• (не менять — оставьте пустым)':'пароль приложения' ?>"></div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
    <div class="adm-field"><label>От кого (email)</label><input type="text" name="smtp_from" value="<?= e(setting('smtp_from')) ?>" placeholder="no-reply@gatewaytodreams.info"></div>
    <div class="adm-field"><label>Имя отправителя</label><input type="text" name="smtp_from_name" value="<?= e(setting('smtp_from_name')) ?>"></div>
  </div>
  <button class="adm-btn" type="submit">Сохранить email-настройки</button>
</form>

<form method="post" class="adm-card">
  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
  <input type="hidden" name="action" value="test_mail">
  <h2>Проверка почты</h2>
  <div class="adm-field"><label>Отправить тестовое письмо на адрес</label><input type="text" name="test_to" placeholder="ваш@email.com"></div>
  <button class="adm-btn green" type="submit">Отправить тест</button>
</form>

<form method="post" class="adm-card" enctype="multipart/form-data">
  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
  <input type="hidden" name="action" value="contract">
  <h2>Реквизиты договора (Исполнитель)</h2>
  <p class="muted" style="margin:-6px 0 14px;font-size:.85rem">Подставляются в договор клиента вместо плейсхолдеров. ФИО, паспорт и дата заказчика берутся из анкеты автоматически.</p>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
    <div class="adm-field"><label>Наименование компании</label><input type="text" name="co_name" value="<?= e(setting('co_name')) ?>"></div>
    <div class="adm-field"><label>Город заключения</label><input type="text" name="contract_city" value="<?= e(setting('contract_city')) ?>"></div>
  </div>
  <div class="adm-field"><label>Должность и ФИО руководителя</label><input type="text" name="co_director" value="<?= e(setting('co_director')) ?>" placeholder="Директор Иванов И.И."></div>
  <div class="adm-field"><label>Действует на основании</label><input type="text" name="co_basis" value="<?= e(setting('co_basis')) ?>" placeholder="Устава / Доверенности №..."></div>
  <div class="adm-field"><label>Реквизиты (для блока подписи)</label><textarea name="co_requisites" rows="3" placeholder="ИНН, адрес, банк, счёт..."><?= e(setting('co_requisites')) ?></textarea></div>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
    <div class="adm-field">
      <label>Печать (PNG, лучше без фона)</label>
      <?php if ($seal = setting('co_seal_file')): ?>
        <div style="margin-bottom:8px"><img src="/data/uploads/<?= e($seal) ?>" style="max-height:90px;background:#f5f7fa;border:1px solid var(--border);border-radius:8px;padding:6px"></div>
        <label class="switch" style="font-size:.85rem;font-weight:500"><input type="checkbox" name="remove_seal" value="1"> удалить печать</label>
      <?php endif; ?>
      <input type="file" name="co_seal" accept="image/png,image/jpeg">
    </div>
    <div class="adm-field">
      <label>Подпись (PNG, лучше без фона)</label>
      <?php if ($sign = setting('co_signature_file')): ?>
        <div style="margin-bottom:8px"><img src="/data/uploads/<?= e($sign) ?>" style="max-height:90px;background:#f5f7fa;border:1px solid var(--border);border-radius:8px;padding:6px"></div>
        <label class="switch" style="font-size:.85rem;font-weight:500"><input type="checkbox" name="remove_signature" value="1"> удалить подпись</label>
      <?php endif; ?>
      <input type="file" name="co_signature" accept="image/png,image/jpeg">
    </div>
  </div>
  <button class="adm-btn" type="submit">Сохранить реквизиты договора</button>
</form>

<form method="post" class="adm-card">
  <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
  <input type="hidden" name="action" value="admin_creds">
  <h2>Доступ администратора</h2>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
    <div class="adm-field"><label>Логин</label><input type="text" name="admin_user" value="<?= e(setting('admin_user')) ?>"></div>
    <div class="adm-field"><label>Новый пароль</label><input type="password" name="admin_pass" placeholder="оставьте пустым, чтобы не менять"><small>минимум 6 символов</small></div>
  </div>
  <button class="adm-btn red" type="submit">Обновить доступ</button>
</form>
<?php admin_foot();
